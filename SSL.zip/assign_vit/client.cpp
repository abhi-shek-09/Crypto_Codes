#include <iostream>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

void initializeSSL() {
    SSL_load_error_strings();
    OpenSSL_add_ssl_algorithms();
}

int openConnection(const char *hostname, int port) {
    int sd;
    struct sockaddr_in addr;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(hostname);

    sd = socket(AF_INET, SOCK_STREAM, 0);
    if (sd < 0) {
        perror("Unable to create socket");
        exit(EXIT_FAILURE);
    }

    if (connect(sd, (struct sockaddr*)&addr, sizeof(addr)) != 0) {
        perror("Unable to connect");
        exit(EXIT_FAILURE);
    }

    return sd;
}

void shutdownSSL() {
    EVP_cleanup();
}
void cleanup_openssl() {
    ERR_free_strings();
    EVP_cleanup();
}

int main(int argc, char **argv) {
    SSL_CTX *ctx;
    int server;
    SSL *ssl;

    initializeSSL();
    ctx = SSL_CTX_new(TLS_client_method());

    if (!SSL_CTX_load_verify_locations(ctx, "ca.pem", NULL)) {
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }

    server = openConnection("127.0.0.1", 4433);
    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, server);

    if (SSL_connect(ssl) == -1) {
        ERR_print_errors_fp(stderr);
    } else {
        char msg[] = "Hello, SSL!";
        printf("Connected with %s encryption\n", SSL_get_cipher(ssl));
        SSL_write(ssl, msg, strlen(msg));

        char buffer[1024] = {0};
        int bytes = SSL_read(ssl, buffer, sizeof(buffer));
        buffer[bytes] = 0;
        printf("Received: %s\n", buffer);
    }

    SSL_free(ssl);
    close(server);
    SSL_CTX_free(ctx);
    cleanup_openssl();
}

